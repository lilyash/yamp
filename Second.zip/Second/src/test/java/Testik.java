import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Testik {
    @DataProvider
    public static Object[][] testGetRootsData(){
        return new Object[][]{
                {1, 0, -9, 3},
                {0, 1, 5, -5},
                {0, 2, 4, -2},
                {1, -5, 6, 3},
                {1, 10, 24, -4}
        };
    }

    @Test
    public void testConstruct(){
        AnotherPolynom obj = new AnotherPolynom(1, 2, 3);
        Assert.assertNotNull(obj);
    }

    @Test (dataProvider = "testGetRootsData")
    public void testGetRoots(double a, double b, double c, double y)throws EpicFailException {
        AnotherPolynom obj = new AnotherPolynom(a, b, c);
        Assert.assertEquals(obj.returnMaxRoot(), y);
    }
}
