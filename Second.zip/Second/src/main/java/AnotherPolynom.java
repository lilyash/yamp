public class AnotherPolynom {
    private Polynom poly;

    public AnotherPolynom(double a, double b, double c){
        poly = new Polynom(a,b,c);
    }

    public double returnMaxRoot() throws EpicFailException{
        double[] roots= poly.getRoots();
        if (roots[0]==roots[1]){ return roots[1];}
        if (roots[0]<roots[1]){return roots[1];}
        else{return roots[0];}
    }
}
