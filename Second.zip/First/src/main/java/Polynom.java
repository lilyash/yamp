public class Polynom {
    private double a, b, c;

    public Polynom(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }
    public double[] getRoots()throws EpicFailException {
        double d, x, x1, x2;
        double[] roots= new double[2];
        if (a == 0 && b == 0 && c != 0) {
            throw new EpicFailException("WAI!");
    }
        if (a == 0) {
            if (b == 0 && c == 0) {
               throw new EpicFailException("Ошибка");
            } else {
                roots[0] = (-c) / b;
                roots[1] = (-c) / b;
            }
        } else {
            if (b == 0 && c == 0) {
                throw new EpicFailException("Ошибка");
            } else {
                d = ((b * b) - (4 * a * c));
                if (d < 0) {
                    throw new EpicFailException("Ошибка");
                }
                if (d >= 0) {
                    roots[0] = (((-b) - Math.sqrt(d)) / (2 * a));
                    roots[1] = (((-b) + Math.sqrt(d)) / (2 * a));
                }
            }
        }
        return roots;
    }
}
