public class EpicFailException extends Throwable {
    public EpicFailException() {
    }

    public EpicFailException(String message) {
        super(message);
    }

    public EpicFailException(String message, Throwable cause) {
        super(message, cause);
    }

    public EpicFailException(Throwable cause) {
        super(cause);
    }
}
