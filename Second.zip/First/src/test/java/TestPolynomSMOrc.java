import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestPolynomSMOrc {
    @DataProvider
    public static Object[][] testGetRootsData(){
        return new Object[][]{
                {1, 0, -9, -3, 3},
                {0, 1, 5, -5, -5},
                {0, 2, 4, -2, -2},
                {1, -5, 6, 2, 3},
                {1, 10, 24, -6, -4}
        };
    }

    @Test
    public void testConstruct(){
        Polynom obj = new Polynom(1, 2, 3);
        Assert.assertNotNull(obj);
        Assert.assertEquals(obj.getA(), 1.0);
        Assert.assertEquals(obj.getB(), 2.0);
        Assert.assertEquals(obj.getC(), 3.0);
    }

@Test (dataProvider = "testGetRootsData")
public void testGetRoots(double a, double b, double c, double x, double y)throws EpicFailException {
        Polynom obj = new Polynom(a, b, c);
        double[] roots = obj.getRoots();
        Assert.assertEquals(roots[0], x);
        Assert.assertEquals(roots[1], y);
    }
}
